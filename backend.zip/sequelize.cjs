// sequelize.cjs - CJS bridge to run CLI
module.exports = require('sequelize-cli/lib/sequelize');
